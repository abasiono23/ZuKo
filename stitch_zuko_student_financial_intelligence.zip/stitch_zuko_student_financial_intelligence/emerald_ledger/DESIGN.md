---
name: Emerald Ledger
colors:
  surface: '#f7f9fe'
  surface-dim: '#d7dade'
  surface-bright: '#f7f9fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f8'
  surface-container: '#ebeef2'
  surface-container-high: '#e5e8ec'
  surface-container-highest: '#e0e3e7'
  on-surface: '#181c1f'
  on-surface-variant: '#404942'
  inverse-surface: '#2d3134'
  inverse-on-surface: '#eef1f5'
  outline: '#707971'
  outline-variant: '#bfc9c0'
  surface-tint: '#226b47'
  primary: '#004328'
  on-primary: '#ffffff'
  primary-container: '#0d5c3a'
  on-primary-container: '#8ad2a7'
  inverse-primary: '#8ed6aa'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#1b4031'
  on-tertiary: '#ffffff'
  tertiary-container: '#335748'
  on-tertiary-container: '#a4cbb8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a9f3c5'
  primary-fixed-dim: '#8ed6aa'
  on-primary-fixed: '#002111'
  on-primary-fixed-variant: '#005232'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#c3ecd7'
  tertiary-fixed-dim: '#a8cfbc'
  on-tertiary-fixed: '#002115'
  on-tertiary-fixed-variant: '#294e3f'
  background: '#f7f9fe'
  on-background: '#181c1f'
  surface-variant: '#e0e3e7'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: '0'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: '0'
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  currency-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  currency-tabular:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: '0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an intelligent, grounded, and empowering financial platform built for tertiary students and burgeoning campus entrepreneurs in Nigeria. The brand rejects the loud gamification and neon gimmicks prevalent in speculative fintech, instead projecting institutional poise, absolute clarity, and proactive financial intelligence.

### Design Movement & Aesthetic
The interface adopts a **Tactile Modernist Fintech** aesthetic:
- **Calm, High-End Utility:** Grounded paper-like canvas foundations paired with rich botanical emerald tones that evoke Nigerian financial prosperity, security, and sustained growth.
- **Editorial FinTech Precision:** Sharp tabular typography for Nigerian Naira (`₦`) figures, quiet micro-borders, and high-legibility text designed for readability across low-end Android smartphones through to high-density laptop displays.
- **Cognitive Clarity:** Generous negative space paired with clear categorical containment. Analytical depth is revealed through soft tint variations rather than dense visual clutter.

## Colors

The palette balances warm organic foundations with institutional emerald greens and crisp functional indicators.

### Palette Hierarchy & Intent
- **Canvas & Surfaces:**
  - `Surface Base`: `#FBFBFA` — Warm, off-white foundation that eliminates cold eye strain.
  - `Surface Elevated`: `#FFFFFF` — Pure white reserved for cards, sheets, and modular containers.
  - `Surface Subdued`: `#F4F4F1` — Used for table headers, embedded sub-panels, and disabled states.
- **Primary Emerald Suite:**
  - `Primary Deep`: `#0D5C3A` — Key buttons, primary actions, and brand presence.
  - `Primary Shade`: `#0A4A2E` — Hover and pressed interactions for primary buttons.
  - `Mint Accent`: `#10B981` — Positive cash flow markers, budget achievements, and growth metrics.
  - `Mint Wash`: `#D1FAE5` — Container background for badges, chips, and AI insight highlights.
- **Neutrals & Typography:**
  - `Text Primary`: `#1A1E21` — High-contrast charcoal for core ledger headings and critical values.
  - `Text Secondary`: `#4B5563` — Body copy, supporting instructions, and metadata.
  - `Text Muted`: `#6B7280` — Micro-labels, input hints, and inactive states.
  - `Border Soft`: `#E5E7EB` — Crisp neutral structural gridlines.
  - `Border Emerald`: `rgba(13, 92, 58, 0.12)` — Subtle brand-tinted outlines on featured cards.
- **Functional Semantics:**
  - `Critical/Expense`: `#DC2626` / Wash `#FEE2E2` (Over-budget notices, debits).
  - `Warning/Pending`: `#D97706` / Wash `#FEF3C7` (Upcoming semester fees, unsettled peer payouts).
  - `Info/AI Intel`: `#0284C7` / Wash `#E0F2FE` (Algorithmic predictions, automated savings tags).

## Typography

Typography pairs the structural warmth of **Plus Jakarta Sans** for prominent headers and balance displays with the clinical legibility of **Inter** for dense transactional tables, data analytics, and micro-copy.

### Financial Number Rules
- Always enforce OpenType tabular figures (`font-variant-numeric: tabular-nums;`) across all transaction listings, account balances, and percentage metrics to maintain vertical column alignment.
- The Nigerian Naira currency sign (`₦`) must render at matching cap-height to adjacent numerals without visual baseline shift.

## Layout & Spacing

The layout model is driven by a rhythmic, 12-column adaptive fluid grid for desktop and tablet screens, shifting to a unified 4-column structure for mobile viewports.

### Breakpoints & Canvas Geometry
- **Mobile (`< 768px`):** 4 columns, `1rem` outer canvas margin, `1rem` gutter. Critical actions dock to a fixed bottom navigation bar (`64px` height + safe area).
- **Tablet (`768px – 1024px`):** 8 columns, `1.5rem` outer canvas margin, `1.25rem` gutter. Collapsible sidebar navigation.
- **Desktop (`> 1024px`):** 12 columns, max-content container width of `1280px`, `2rem` outer canvas margin, `1.5rem` gutter. Fixed left rail (`260px` width) for ecosystem-level hierarchy.

### Vertical Rhythm
Internal element distribution prioritizes breathing room around core ledger numbers to combat financial stress. Metric panels and cards utilize `space-lg` (`1.5rem`) internal padding on desktop and `space-md` (`1rem`) on small viewports.

## Elevation & Depth

This system avoids floating drop shadows in favor of **Crisp Low-Contrast Outlines** combined with **Tonal Grounding** and **Micro-Ambient Diffusions**.

### Depth Layers
- **Layer 0 (Canvas Base):** Flat `#FBFBFA`.
- **Layer 1 (Modular Surfaces & Cards):** Flat `#FFFFFF` bound by a solid `1px` border of `#E5E7EB`.
- **Layer 2 (Elevated Menus & Dropdowns):** `#FFFFFF` paired with an ultra-soft ambient shadow: `0px 4px 16px -2px rgba(26, 30, 33, 0.06), 0px 1px 2px 0px rgba(26, 30, 33, 0.04)` and `1px` border `#E5E7EB`.
- **Layer 3 (Modals & Overlays):** Background backdrop blur (`backdrop-filter: blur(6px)`) with `rgba(26, 30, 33, 0.4)` scrim. Modal containers feature `0px 12px 32px -4px rgba(26, 30, 33, 0.12)`.

### Border Accentuation
Special surfaces (e.g., AI Insight Cards and Active Savings Goals) leverage a tinted boundary: `1px solid rgba(13, 92, 58, 0.15)` to softly differentiate strategic intelligence from routine transactional rows.

## Shapes

The design uses moderate, humanized corner radii to balance contemporary consumer accessibility with banking structure.

### Radius Assignments
- **Inputs, Buttons, and Chips:** `0.5rem` (`8px`) for immediate affordance and tap recognition.
- **Financial Cards, AI Panels, and Dialogs:** `1rem` (`16px`) to soften analytical modules.
- **Sheet Drawers and Large Containers:** `1.5rem` (`24px`) along top sheet perimeters.
- **Status Pills and Badges:** Fully rounded (`9999px`) to create clear visual separation from rectangular actionable surfaces.

## Components

### Buttons
- **Primary:** Background `#0D5C3A`, text `#FFFFFF`, border none, hover state `#0A4A2E`. Active scale down to `0.98`. Focus ring: `2px solid #10B981` with `2px` offset.
- **Secondary:** Background `#FFFFFF`, text `#1A1E21`, border `1px solid #E5E7EB`, hover state `#F4F4F1`.
- **Ghost/Tertiary:** Background transparent, text `#0D5C3A`, hover state `#D1FAE5` at `40%` opacity.

### Financial Metric Cards
- Background `#FFFFFF`, `1px solid #E5E7EB`, `1rem` rounded corners, `1.5rem` inner padding.
- Metric values rendered in `Plus Jakarta Sans` with OpenType tabular numerals.
- Top-right placement for a trend badge: `10px` pill badge with light mint background `#D1FAE5`, dark green text `#065F46`, and upward vector indicator.

### AI Insight Callout
- Background: Subdued tint of `#F4FAF7` with a structural border: `1px solid rgba(13, 92, 58, 0.2)`.
- Iconography: A minimal sparkline or geometric node in `#0D5C3A` inside a `28px` rounded square.
- Content: Headline in `headline-sm`, recommendation copy in `body-md` (`#2D3135`), followed by contextual actionable micro-buttons (e.g., *"Adjust Weekly Target"*).

### Affordability Breakdown & Budget Meters
- Progress Bars: Track height `6px`, background `#E5E7EB`, rounded `9999px`.
- Fill track: Solid `#0D5C3A` for healthy margins, transitioning to `#D97706` at 85% capacity and `#DC2626` when exceeded. No gradient sweeps.

### Input Fields & Controls
- Form Fields: Height `44px`, background `#FFFFFF`, border `1px solid #E5E7EB`, text `#1A1E21`, placeholder `#6B7280`. Focused state: border `#0D5C3A` with a soft box-shadow `0 0 0 3px rgba(13, 92, 58, 0.1)`.
- Currency Prefix: Fixed leading container displaying `₦` in medium-weight `#6B7280`.
- Checkboxes & Radios: Selected state `#0D5C3A` with sharp white indicators. Unchecked state: `1.5px solid #D1D5DB`.

### Navigation
- **Desktop Sidebar:** Left edge fixed at `260px`. Background `#FBFBFA`, right border `1px solid #E5E7EB`. Active navigation item: `#FFFFFF` pill card with `1px solid #E5E7EB`, left indicator bar in `#0D5C3A` (`3px` width), and primary text `#0D5C3A`.
- **Mobile Bottom Navigation:** Fixed bottom dock (`64px` tall). Background `#FFFFFF` with top border `1px solid #E5E7EB`. Icon size `22px` stroke, label in `label-sm`. Active state `#0D5C3A`, inactive `#6B7280`.